﻿namespace impl1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            /*


            nums[2]
            numSum
            numToString
            leastSigString
            restOfString
            addLeastSig()
            

            Implementation
            */


            int[] nums = new int[2];
            nums[0] = 0;
            nums[1] = 0;
            int numSum = 0;
            bool isInt = false;

            

            Console.WriteLine("Hello! I will take two numbers you input, then add them together, then separate the least significant digit and add it to the remaining digits. I will continue to separate the least significant digit and add it to the remaining digits until I am left with only a single digit.\n\nType \"exit\" and hit enter if you wish to exit the program early.\n");
            Thread.Sleep(2000);


            //Accepts first input and makes sure it is a valid integer
            do {

                Console.WriteLine("Please input the first integer...");
                string input = Console.ReadLine();

                if (input == "exit") {
                    ExitProgram();
                }

                isInt = int.TryParse(input, out nums[0]);

                if (!isInt)
                    Console.WriteLine("That is not a valid integer\n");
                


            } while (!isInt);

            Console.WriteLine("\nGreat! Please input the second integer...");


            //Accepts second input and makes sure it is a valid integer
            do
            {

                Console.WriteLine("Please input the second integer...");
                string input = Console.ReadLine();

                if (input == "exit")
                {
                    ExitProgram();
                }

                isInt = int.TryParse(input, out nums[1]);

                if (!isInt)
                    Console.WriteLine("That is not a valid integer\n");



            } while (!isInt);

            Console.WriteLine("Perfect! now I will add these together, then add the least significant digit to the rest of the integer until it is only one digit");
            numSum = nums[0] + nums[1];

            Console.WriteLine("The sum of the numbers is " +  numSum);
            Console.WriteLine("\nThe final integer is " + addLeastSig(numSum) + "!");
            Thread.Sleep(2000);

            //recursive function that adds the least significant digit to the rest of the integer until it is only one digit
            int addLeastSig(int input) {

                
                string numToString = input.ToString();
                if (numToString.Length <= 1) {
                    Thread.Sleep(1000);
                    return input;
                }
                else {
                    string leastSigString = numToString.Substring(numToString.Length - 1);
                    string restOfString = numToString.Substring(0, numToString.Length - 1);
                    Thread.Sleep(500);
                    Console.WriteLine(restOfString + " + " + leastSigString + " = " + (int.Parse(leastSigString) + int.Parse(restOfString)));

                    return addLeastSig(int.Parse(leastSigString) + int.Parse(restOfString));
                }
                
            }

            //Exits the program
            void ExitProgram() {
                Console.WriteLine("\n\nGoodbye!");
                Thread.Sleep(1000);
                Environment.Exit(0);
            }

        }
    }
}
